# exp592 XGBoost 官方语义核查

日期为 2026-10-22。本项只阅读现有代码、训练记录及官方文档/源码；未连接远端，未运行算法、训练、数值审计、评分或性能测试。检索先使用 Context7，再核对 `v3.0.5` 官方源码。当前文档包含后续版本行为，以下按固定版本解释。

## 版本与当前调用

`validation/results/exp579/training.json:311` 记录 `xgboost_version=3.0.5`。`validation/exp557_evaluate.py:273`、`validation/exp576_routed_residual.py:203`、`validation/exp579_complete_candidate.py:362` 均检查该版本。

R8 最终训练使用 `reg:absoluteerror`、CPU `hist`、`max_depth=4`、`eta=.3`、`max_bin=256`、`base_score=0`、`subsample=1`、`colsample_bytree=1`、8 轮。`min_child_weight`、`reg_lambda`、`reg_alpha`、`gamma` 使用默认值，依次为 1、1、0、0 [S2,S3]。每行权重为 `1000/max(d0+mandatory,128)`；目标为 `d0-base`，见 `validation/exp579_complete_candidate.py:171`。

## 1. 加权 L1 同时影响分裂与叶值

`MeanAbsoluteError::GetGradient` 使用 `g=w*sign(pred-label)`、`h=w`，`sign(0)=0`。这里的 `h` 是算法采用的正代理曲率。树建立后，`UpdateTreeLeaf` 走 `alpha=.5` 的分位数更新：以当前残差 `label-pred` 的加权中位数产生叶值，再乘本轮学习率 [S1,S4,S9]。

因此，同权重下非零残差的大小直接体现在叶内中位数，分裂梯度仅保留正负号。原零残差行仍有正 `h`；若它们与其他残差混入同一叶，叶内加权中位数可能移动。这解释了可检验的污染机制；污染量、死区和门控收益仍需现有完整请求的配对消融。最终叶值经这条分位数路径替换，通用二阶公式中的 `reg_lambda`/`reg_alpha` 对叶值的收缩不能原样套用；它们仍参与树结构的增益计算 [S3,S4]。

## 2. `min_child_weight` 是加权覆盖量

该版本检查子节点 `sum(h)`。当前加权 L1 下，它等于叶内样本权重之和 [S1,S3]。例如，代理分母为 10000 时每行权重为 .1，默认阈值 1 对应至少十行的覆盖量；分母不超过 128 时单行权重为 7.8125，一个样本即可越过这一覆盖门槛。真实可分裂性还受增益、深度及其他条件限制。

**待验证异常候选**是不同路由、延迟段的有效容量可能差异很大。调大该参数需要先统计加权覆盖分布；exact 图最短路标签的学习曲线和重复求解证据，分别用于判断容量与标签稳定性。

## 3. 整体权重倍数改变正则比例

根据分裂公式作条件推导：固定候选分区并将全部权重乘 `c>0` 时，`G,H` 同时乘 `c`。当 `reg_alpha=0` 时，单项增益成为 `c*G^2/(H+lambda/c)`。相对于原权重，固定 `lambda`、`min_child_weight` 分别对应 `lambda/c`、`min_child_weight/c`；正 `gamma` 的相对门槛也发生变化 [S3]。

因此，`1000/y` 与 `1/y` 配同一组默认参数，会采用不同的结构正则强度。保持正则比例的对照应同步缩放 `lambda`、`alpha`、`min_child_weight`、`gamma`。这是公式层面的比例关系，浮点累计、候选并列和近似分桶仍需单独核对；本文未声称逐位等价。固定叶分区时，加权中位数对统一正倍数保持不变 [S4]。

## 4. 初始化已有明确设置

3.0.5 的 learner 在用户显式设置 `base_score` 后，将 `boost_from_average` 关闭；仅在启用自动估计且模型尚未拟合时调用 `InitEstimation` [S5]。当前 `base_score=0`，导出也检查该值，见 `validation/exp579_complete_candidate.py:87`，因而自动估计截距不构成当前已证实异常。改用自动截距、`base_margin` 或不同目标后，应重新检查导出包含的初始化项。

## 5. `hist` 的容量约束包含分桶

3.0.5 的 `hist` 在训练前按用户权重建立全局 sketch，后续节点沿用这些候选；`max_bin` 控制连续特征候选桶数 [S2,S6]。因此当前权重会同时影响误差目标、分裂统计和切分候选。低频拓扑状态是否因分桶被合并，属于可用 `max_bin` 消融验证的假设。

当前行、列采样率均为 1，随机子采样不是该配置的既有解释。3.0.5 的 CPU `hist` 仅支持 uniform 行采样，`gradient_based` 在该版本需 GPU [S6]。Context7 还能检索到标注 3.2.0 才支持 CPU 的新行为；当前项目应保持版本区别。

## 6. 缺失值与原生导出

官方数值节点以 `feature < threshold` 选择左支；缺失值单独使用模型的默认分支 [S7]。当前 `src/xgb_residual_base47_fast.h:22` 保留严格小于比较，其直接比较没有缺失值分支，适用边界是所有输入特征有限且其 sentinel 约定保持。`validation/exp576_routed_residual.py:214` 检查离线矩阵有限，`validation/exp579_complete_candidate.py:235` 包含完整在线特征逐位检查；本项未重新执行这些检查。

当前 exp579 导出读取 `split_conditions` 的已训练叶值，并直接累加，代码未再次乘 `eta`，与叶更新已乘学习率相符 [S9]。还需持续保留阈值等值边界、`float32` 比较、原生叶序、累加顺序、初始化及最终整数舍入的等价检查。仅 JSON 重新加载等价，覆盖的范围是序列化；手写推理与特征生成的检查另有作用。

## 7. 官方 tanh 分数不能直接提供正的真实 Hessian

以下为数学推导，前提是 `truth=y>0`、连续预测、误差 `e=pred-y`。最小化与单行官方分数对应的损失 `L=tanh(k*abs(e))`，其中 `k=4/y`。在 `e!=0` 时：

```text
g = k*sign(e)*sech(k*abs(e))^2
h = -2*k^2*sech(k*abs(e))^2*tanh(k*abs(e)) < 0
```

`e=0` 为不可微尖点。零真值分支及最终整数舍入需另行处理。官方自定义目标指南要求目标具有可用曲率，并说明负 Hessian 会被截断；提供正曲率上界或替代 Hessian 属于另一种优化近似 [S8]。因此当前应首先用最终整数输出的官方指标选型，再验证代理损失、分母下限和分组容量；若采用自定义目标，须同时标明其梯度、代理曲率、权重和边界假设。

## 对主审计的判定边界

- 已证实的语义风险包括权重与结构正则耦合、L1 分裂忽略残差幅度、加权分桶及缺失值的导出前提。它们各自的实测损失贡献尚待消融。
- `validation/exp576_routed_residual.py:72` 以 `folds!=fold` 训练、`folds==fold` 预测，至少这一层已有 OOF。上游背景是否曾用同一请求标签、分组是否隔离真实相关族，需沿数据身份继续追踪。
- `validation/exp579_complete_candidate.py:181` 在训练集生成 native 输出用于导出核对。训练集预测存在这一事实，只支持核对用途；泄漏判断还需看选型与验证集的实际用途和交集。
- 特征重叠、较深的树、MAE 下降分别构成检查线索。当前证据允许将机制与失分逐项关联，尚不足以分别认定因果。

## 官方来源

- S1 `v3.0.5/src/objective/regression_obj.cu`，`MeanAbsoluteError`：https://raw.githubusercontent.com/dmlc/xgboost/v3.0.5/src/objective/regression_obj.cu
- S2 `v3.0.5/doc/parameter.rst`，参数默认值、`max_bin`、L1 说明：https://raw.githubusercontent.com/dmlc/xgboost/v3.0.5/doc/parameter.rst
- S3 `v3.0.5/src/tree/param.h`，`TrainParam`、`CalcWeight`、`CalcGain`：https://raw.githubusercontent.com/dmlc/xgboost/v3.0.5/src/tree/param.h
- S4 `v3.0.5/src/objective/adaptive.cc`，加权分位数及最终叶值：https://github.com/dmlc/xgboost/blob/v3.0.5/src/objective/adaptive.cc
- S5 `v3.0.5/src/learner.cc`，显式截距与 `InitBaseScore`：https://raw.githubusercontent.com/dmlc/xgboost/v3.0.5/src/learner.cc
- S6 `v3.0.5/doc/treemethod.rst`，sketch 与 CPU/GPU 采样矩阵：https://github.com/dmlc/xgboost/blob/v3.0.5/doc/treemethod.rst
- S7 `v3.0.5/src/predictor/predict_fn.h`，`GetDecision`、`GetNextNode`：https://raw.githubusercontent.com/dmlc/xgboost/v3.0.5/src/predictor/predict_fn.h
- S8 `v3.0.5/doc/tutorials/advanced_custom_obj.rst`，自定义目标假设与负曲率边界：https://github.com/dmlc/xgboost/blob/v3.0.5/doc/tutorials/advanced_custom_obj.rst
- S9 `v3.0.5/src/objective/adaptive.h`，`UpdateLeafValues` 的 `q*learning_rate`：https://raw.githubusercontent.com/dmlc/xgboost/v3.0.5/src/objective/adaptive.h

其中 S1、S2、S3、S5、S7、S9 由 raw 原文核对；S4、S6、S8 的部分 raw 请求返回超时或内部错误，改读同一官方标签的 GitHub 文件页。Context7 用于发现官方文档和版本差异，具体实现以 3.0.5 为准。
