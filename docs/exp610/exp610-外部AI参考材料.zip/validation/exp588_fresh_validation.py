#!/usr/bin/env python3
"""Reuse exact-label generation for the frozen directional-background holdout."""
import argparse
import csv
import gzip
from pathlib import Path
import shutil
import socket

import exp501_fresh_full_labels as previous
from exp208_nominal_parent_tree import identity, write

ROOT, BUILD = Path("validation/results/exp588"), Path("build/exp588")
PLAN = Path("experiment/实验588-冻结方向背景候选的独立全端口1M.md")
previous.ROOT, previous.BUILD, previous.PLAN = ROOT, BUILD, PLAN
previous.TOOLS = BUILD / "tools"


def prepare():
    assert socket.gethostname() == "lhj-R4900-G3"
    assert Path.cwd() == Path("/home/lhj/lhjwork/eda2026/research/exp588")
    ROOT.mkdir(parents=True)
    BUILD.mkdir(parents=True)
    shutil.copyfile(PLAN, ROOT / "protocol-original.md")
    source = Path("../exp589/validation/results/exp589")
    report = previous.read(source / "report.json")
    frozen = previous.read(source / "candidate-freeze.json")
    eligible = report["scale_eligible"]
    selected = max(eligible, key=lambda name: min(
        case["stats"][name]["score_extrapolated_1b"]
        for case in report["cases"].values()))
    assert selected == "D64"
    candidates = {"D64": (Path("../exp589/build/exp589/D64"), frozen["arms"]["D64"]["binary"]),
                  "N512": (Path("../exp586/build/exp586/N512"), frozen["baseline"])}
    binaries = {}
    for name, (path, expected) in candidates.items():
        actual = identity(path)
        assert all(actual[k] == expected[k] for k in ("bytes", "sha256")), name
        binaries[name] = actual
    write(ROOT / "selection.json", dict(selected=selected, binaries=binaries,
        source_report=identity(source / "report.json"),
        source_freeze=identity(source / "candidate-freeze.json"),
        rule="highest worst-case registered combined-score point estimate on the two used datasets",
        fresh_requests_generated=False, fresh_scores_seen=False))
    known, history = previous.prior_pairs()
    research = sorted({p for p in Path("../../research").glob("exp*/**/*exact*.csv")
                       if p.is_file()})
    public = Path("doc/eda比赛文件/data/delay_estimate_ans.csv")
    extra = []
    for path in [*research, public]:
        with path.open(newline="") as stream:
            reader = csv.DictReader(stream)
            names = reader.fieldnames or []
            a = next((v for v in ("from", "From") if v in names), None)
            b = next((v for v in ("to", "To") if v in names), None)
            assert a and b, (path, names)
            count = 0
            for row in reader:
                known.add((row[a], row[b]))
                count += 1
        extra.append(dict(file=identity(path), rows=count))
    with gzip.open(BUILD / "known-local.csv.gz", "wt", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(("From", "To"))
        writer.writerows(sorted(known))
    history.update(extra_files=extra, unique_pairs=len(known),
                   requests=identity(BUILD / "known-local.csv.gz"))
    write(ROOT / "history-local.json", history)
    paths = [Path(__file__).resolve().relative_to(Path.cwd()),
             Path(previous.__file__).resolve().relative_to(Path.cwd()),
             PLAN, ROOT / "protocol-original.md", ROOT / "selection.json",
             ROOT / "history-local.json", BUILD / "known-local.csv.gz"]
    paths += [Path("validation") / (name + ".py") for name in
              ("exp208_nominal_parent_tree", "exp462_unique_1b", "exp482_full_role_baseline")]
    paths += sorted(previous.ARCH.glob("*.json"))
    expected = previous.read("../exp501/validation/results/exp501/freeze.json")["expected_tools"]
    write(ROOT / "freeze.json", dict(files=[identity(p) for p in paths], rows=previous.ROWS,
        proposal_seed=20261022588, shuffle_seed=20261023588,
        source_ports=previous.roles()[0], target_ports=previous.roles()[1],
        required_port_pairs=59904, expected_tools=expected, untouched_scores=True,
        selected_candidate="D64", disk_start_bytes=shutil.disk_usage(".").free,
        cpu_estimate_s=4250))
    print("EXP588_CANDIDATE_AND_HOLDOUT_FROZEN", len(known), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("prepare", "dataset", "labels", "verify"))
    stage = parser.parse_args().stage
    if stage == "labels":
        assert socket.gethostname() == "lhj-NF5280M5"
    (prepare if stage == "prepare" else getattr(previous, stage))()
