#!/usr/bin/env python3
"""Keep ISA selection outside the complete request loop and inline fixed dots."""
from pathlib import Path
import shutil
import socket
import subprocess
import sys

sys.path.insert(0, str(Path('../exp607/validation').resolve()))
import exp607_cpu_dispatch as prior

ROOT, BUILD = Path('validation/results/exp608'), Path('build/exp608')
PLAN = Path('experiment/实验608-启动分派整查询内联的SIMD路径.md')
ARMS = ('A', 'F', 'S', 'D')
read, write, identity, check = prior.read, prior.write, prior.identity, prior.check
prior.ROOT, prior.BUILD, prior.speed.ROOT = ROOT, BUILD, ROOT


def link(arm, avx=0, sse=0):
    template = read('../exp601/validation/results/exp601/compile-PQ.run.json')['command']
    records = {}
    for suffix in ('', '-audit'):
        name = arm + suffix
        command = [c for c in template if c != 'build/exp601/PQ.cpp']
        command[-1] = str(BUILD / name)
        command[1:1] = [str(BUILD / 'entry.cpp'), *[str(BUILD / (a + suffix + '.o')) for a in ('F', 'S', 'D')],
                       f'-DEXP607_ARM={prior.MODES[arm]}', f'-DEXP607_AVX_CHOICE={avx}',
                       f'-DEXP607_SSE_CHOICE={sse}']
        prior.speed.measured(command, 'link-' + name)
        assert not (ROOT / ('link-' + name + '.stderr')).read_bytes()
        assert (BUILD / name).stat().st_size < 100000000
        output = subprocess.run(['ldd', str(BUILD / name)], capture_output=True, text=True)
        assert 'not a dynamic executable' in output.stdout + output.stderr
        records[name] = identity(BUILD / name)
    return records


def build():
    ROOT.mkdir(parents=True, exist_ok=True)
    BUILD.mkdir(parents=True)
    frozen = read('../exp601/validation/results/exp601/freeze.json')
    dependencies = []
    for item in frozen['dependencies']:
        path = Path(item['path'])
        if path.parts[0] != '..': path = Path('../exp601') / path
        check(path, item)
        dependencies.append(identity(path))
    src = Path('../exp601') / frozen['source']['path']
    check(src, frozen['source'])
    text = src.read_text()
    start, end = text.index('extern "C" void* __real_malloc'), text.index('static void require')
    wrapper = text[start:end].replace('static bool querying', 'bool querying').replace('static uint64_t allocations', 'uint64_t allocations')
    text = text[:start] + 'extern bool querying;\nextern uint64_t allocations;\n\n' + text[end:]
    text = prior.prior.replace(text, '#include "exp595_static_geometry.h"', '#include "exp608_geometry.h"')
    text = prior.prior.replace(text, 'count,sizeof(Trace),(unsigned long long)allocations);',
                              'count,sizeof(Trace),(unsigned long long)allocations);\n    return 0;')
    text = prior.prior.replace(text, '(unsigned long long)rows,(unsigned long long)unreachable,(unsigned long long)allocations);',
        '(unsigned long long)rows,(unsigned long long)unreachable,(unsigned long long)allocations);\n    return 0;')
    (BUILD / 'worker.cpp').write_text(text)
    original = Path('../exp595/tests/exp595_static_geometry.h')
    kernel = Path('../exp607/tests/exp607_simd_kernels.cpp')
    header = original.read_text()
    dot = kernel.read_text().split('static inline int dot607', 1)[1].split('template <unsigned Blocks>', 1)[0]
    begin, end = header.index('static inline int dot64_595'), header.index('template <unsigned Group>')
    header = header[:begin] + '#if EXP608_SIMD\n#include <immintrin.h>\nstatic inline int dot64_595' + dot + '#else\n' + header[begin:end] + '#endif\n' + header[end:]
    (BUILD / 'exp608_geometry.h').write_text(header)
    dependencies.extend([identity(original), identity(kernel)])
    reader = Path('../exp601') / frozen['generated_reader']['path']
    check(reader, frozen['generated_reader'])
    for path in (reader, Path('../exp601/build/exp601/exp601_port_parser.h')):
        shutil.copyfile(path, BUILD / path.name)
        dependencies.append(identity(path))
    entry = '#include <cstdint>\n#include <cstdlib>\n#include <cstdio>\n' + wrapper
    entry += '\nint worker608_F(int, char**);\nint worker608_S(int, char**);\nint worker608_D(int, char**);\n'
    entry += r'''
int main(int argc, char** argv) {
    __builtin_cpu_init();
#if EXP607_ARM == 5
#if EXP607_AVX_CHOICE == 1
    if (__builtin_cpu_supports("avx2")) return worker608_D(argc, argv);
#endif
#if EXP607_SSE_CHOICE == 2
    if (__builtin_cpu_supports("sse4.1")) return worker608_S(argc, argv);
#endif
    return worker608_F(argc, argv);
#elif EXP607_ARM == 1
    if (!__builtin_cpu_supports("avx2")) return 1;
    return worker608_D(argc, argv);
#elif EXP607_ARM == 2
    if (!__builtin_cpu_supports("sse4.1")) return 1;
    return worker608_S(argc, argv);
#else
    return worker608_F(argc, argv);
#endif
}
'''
    (BUILD / 'entry.cpp').write_text(entry)
    template = read('../exp601/validation/results/exp601/compile-PQ.run.json')['command']
    for arm, flags in (('F', ['-DEXP608_SIMD=0']), ('S', ['-DEXP608_SIMD=1', '-msse4.1']),
                       ('D', ['-DEXP608_SIMD=1', '-DEXP607_AVX2', '-mavx2'])):
        for suffix in ('', '-audit'):
            name = arm + suffix
            command = [str(BUILD) if c == 'build/exp601' else c for c in template[:template.index('build/exp601/PQ.cpp')]]
            command += flags + ['-Dmain=worker608_' + arm]
            if suffix: command += ['-DEXP579_AUDIT']
            command += ['-c', str(BUILD / 'worker.cpp'), '-o', str(BUILD / (name + '.o'))]
            prior.speed.measured(command, 'compile-' + name)
            assert not (ROOT / ('compile-' + name + '.stderr')).read_bytes()
    binaries = {'A': identity(prior.prior.BASE)}
    for arm in ARMS[1:]: binaries.update(link(arm))
    shutil.copyfile(PLAN, ROOT / 'protocol-original.md')
    write(ROOT / 'build-freeze.json', dict(binaries=binaries, dependencies=dependencies,
        source=identity(BUILD / 'worker.cpp'), entry=identity(BUILD / 'entry.cpp'),
        header=identity(BUILD / 'exp608_geometry.h'), driver=identity(__file__),
        protocol=identity(ROOT / 'protocol-original.md'), disk_start_bytes=shutil.disk_usage('.').free))


def qualify():
    frozen = read(ROOT / 'build-freeze.json')
    prior.audit_arms(ARMS[1:], frozen['binaries'], 'audit.json')
    results = prior.measure(ARMS, frozen['binaries'], 'fixed', 3)
    eligible = [a for a in ('S', 'D') if all(r['stats'][a]['speed_gate'] for r in results.values())]
    write(ROOT / 'fixed-report.json', dict(cases=results, eligible=eligible, all_outputs_identical=True))
    print('EXP608_SELECTED', eligible, flush=True)


def automatic():
    report = read(ROOT / 'fixed-report.json')
    assert report['eligible']
    records = read(ROOT / 'build-freeze.json')['binaries']
    records.update(link('AUTO', 1 if 'D' in report['eligible'] else 0, 2 if 'S' in report['eligible'] else 0))
    write(ROOT / 'automatic-freeze.json', dict(binaries=records, selection=identity(ROOT / 'fixed-report.json')))
    prior.audit_arms(('AUTO',), records, 'automatic-audit.json')
    results = prior.measure(('A', 'F', 'AUTO'), records, 'automatic', 2)
    passed = all(r['stats']['AUTO']['speed_gate'] for r in results.values())
    write(ROOT / 'report.json', dict(cases=results, selected='AUTO' if passed else None,
        all_outputs_identical=True, sse2_fallback_executed=True, other_cpu_performance_verified=False,
        disk_end_bytes=shutil.disk_usage('.').free))
    print('EXP608_AUTOMATIC', passed, flush=True)


if __name__ == '__main__':
    assert socket.gethostname() == 'lhj-R4900-G3'
    assert Path.cwd() == Path('/home/lhj/lhjwork/eda2026/research/exp608')
    assert sys.argv[1:] in (['build'], ['qualify'], ['automatic'])
    {'build': build, 'qualify': qualify, 'automatic': automatic}[sys.argv[1]]()
