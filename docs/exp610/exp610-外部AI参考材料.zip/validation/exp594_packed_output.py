#!/usr/bin/env python3
"""Compare equivalent packed splits and direct CSV formatting on full-port inputs."""
import math
from pathlib import Path
import shutil
import socket
import statistics
import subprocess
import sys

import numpy as np
from scipy.stats import t as student_t

sys.path.insert(0, str(Path('../exp591/validation').resolve()))
import exp591_csv_view as prior

ROOT, BUILD = Path('validation/results/exp594'), Path('build/exp594')
PLAN = Path('experiment/实验594-紧凑树节点与直接行输出.md')
BASE = Path('../exp591/build/exp591/view')
ARMS = ('A', 'P', 'W', 'PW')
read, write, identity = prior.read, prior.write, prior.identity
speed, check = prior.previous.speed, prior.previous.real.check
speed.ROOT = ROOT


def binary(arm):
    return BASE if arm == 'A' else BUILD / arm


def replace(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


def build():
    ROOT.mkdir(parents=True)
    BUILD.mkdir(parents=True)
    old = read('../exp591/validation/results/exp591/freeze.json')
    check(BASE, old['binary'])
    source_path = Path('../exp591/build/exp591/candidate.cpp')
    check(source_path, old['source'])
    source = replace(source_path.read_text(), '#include "exp579-models.h"',
        '#include "exp579-models.h"\n#include "exp594_packed_output.h"')
    begin = source.index('template <typename T>\nstatic inline float residual')
    end = source.index('static inline int side', begin)
    original = source[begin:end]
    packed = replace(original, 'template <typename T>', '')
    packed = replace(packed, 'const T* x', 'const int* x')
    packed = replace(packed, 'kModels[16 * fold + route]', 'kPacked594[16 * fold + route]')
    packed = replace(packed,
        '            path[t] = 2 * path[t] + unsigned(x[m.feature[at]] >= m.threshold[at]);',
        '            const uint32_t node = m.node[at];\n'
        '            path[t] = 2 * path[t] + unsigned(x[node & 255] >= int16_t(node >> 16));')
    source = replace(source, original, '#ifdef EXP594_PACKED\n' + packed + '#else\n' + original + '#endif\n\n')
    source = replace(source, '#ifdef EXP581_INTEGER', '#if defined(EXP581_INTEGER) || defined(EXP594_PACKED)')
    source = replace(source, '    delayest::BufferedWriter writer(out);',
        '#ifdef EXP594_WRITER\n    RowWriter594 writer(out);\n#else\n'
        '    delayest::BufferedWriter writer(out);\n#endif')
    begin = source.index('        char number[24];')
    end = source.index('        ++rows;', begin)
    original = source[begin:end]
    source = replace(source, original, '#ifdef EXP594_WRITER\n'
        '        require(writer.row(text, answer), "output write");\n#else\n' + original + '#endif\n')
    (BUILD / 'candidate.cpp').write_text(source)
    assets = Path('../exp589/build/exp589/D64-assets')
    dependencies = [Path('tests/exp594_packed_output.h'), Path('../exp591/tests/exp591_csv_view.h'),
        assets / 'exp582_int8_geometry.h', assets / 'exp579-models.h', assets / 'geometry.o',
        Path('../exp580/build/exp580/architecture-resolver.o'), Path('../exp579/build/exp579/arch-text.o')]
    common = ['g++', '-std=c++17', '-O3', '-fno-exceptions', '-fno-rtti', '-fno-fast-math',
        '-ffp-contract=off', '-march=x86-64', '-mtune=generic', '-Wall', '-Wextra', '-Werror',
        '-DDELAY_ESTIMATE_EMBEDDED_ARCH', '-DDELAY_ESTIMATE_PRECOMPUTED_RESIDUE',
        '-DEXP580_PORT_PARSER', '-DEXP581_PREFETCH', '-DEXP582_BLOCK=64',
        '-I', '../exp589/src', '-I', str(assets), '-I', 'tests', '-I', '../exp591/tests', '-I', '../exp589/tests']
    for arm in (*ARMS[1:], 'P-audit'):
        flags = (['-DEXP594_PACKED'] if 'P' in arm else []) + (['-DEXP594_WRITER'] if 'W' in arm else [])
        if arm == 'P-audit':
            flags += ['-DEXP579_AUDIT']
        command = common + flags + [str(BUILD / 'candidate.cpp'), *map(str, dependencies[-2:]),
            str(assets / 'geometry.o'), '-static', '-s',
            '-Wl,--wrap=malloc,--wrap=calloc,--wrap=realloc', '-o', str(BUILD / arm)]
        speed.measured(command, 'compile-' + arm)
        assert not (ROOT / ('compile-' + arm + '.stderr')).read_bytes()
        assert (BUILD / arm).stat().st_size < 100000000
        linked = subprocess.run(['ldd', str(BUILD / arm)], capture_output=True, text=True)
        assert 'not a dynamic executable' in linked.stdout + linked.stderr
    shutil.copyfile(PLAN, ROOT / 'protocol-original.md')
    write(ROOT / 'build-freeze.json', dict(binaries={a: identity(binary(a)) for a in ARMS},
        source=identity(BUILD / 'candidate.cpp'), dependencies=[identity(p) for p in dependencies],
        audit_binary=identity(BUILD / 'P-audit'), driver=identity(__file__),
        protocol=identity(ROOT / 'protocol-original.md'), disk_start_bytes=shutil.disk_usage('.').free))


def qualify():
    fixed = read(ROOT / 'build-freeze.json')
    for arm in ARMS:
        check(binary(arm), fixed['binaries'][arm])
    check(BUILD / 'P-audit', fixed['audit_binary'])
    expected = read('../exp589/validation/results/exp589/audit.json')['D64']['trace']
    expected_path = Path('../exp589') / expected['path']
    check(expected_path, expected)
    trace = BUILD / 'packed-trace.bin'
    command = [str(BUILD / 'P-audit'), '../exp579/build/exp579/queries.bin',
        '../exp579/build/exp579/folds.u8', str(trace), '1']
    run = speed.measured(command, 'trace')
    dtype = prior.previous.previous.TRACE
    a, b = [np.memmap(p, mode='r', dtype=dtype, shape=(1000000,)) for p in (trace, expected_path)]
    assert np.abs(a['features']).max() < 2**24
    assert np.array_equal(a['features'], np.floor(a['features']))
    for name in dtype.names:
        assert np.array_equal(np.ascontiguousarray(a[name]).view('u1'), np.ascontiguousarray(b[name]).view('u1')), name
    write(ROOT / 'trace-evidence.json', dict(run=run, output=identity(trace), reference=expected,
        matched_fields=list(dtype.names), rows=1000000, port_pairs=59904, rebuild_command=command))
    del a, b
    trace.unlink()
    results = {}
    critical = float(student_t.ppf(1 - .05 / 6 / 2, 5))
    for case, exp in (('development', 'exp501'), ('robustness', 'exp562')):
        request = Path(f'../{exp}/build/{exp}/u-role/requests.csv')
        old = read(f'../exp589/validation/results/exp589/{case}-report.json')['evidence']['D64']
        check(request, old['input'])
        times, runs = {a: [] for a in ARMS}, []
        orders = [ARMS, *([ARMS, ARMS[::-1]] * 3)]
        write(ROOT / (case + '-timing-freeze.json'), dict(schedule=orders, input=old['input'],
            expected_output=old['output'], critical_t=critical, comparisons=6, alpha=.05))
        for iteration, order in enumerate(orders):
            for arm in order:
                output = BUILD / f'{case}-{iteration}-{arm}.csv'
                command = [str(binary(arm)), '-in', str(request), '-out', str(output)]
                run = speed.measured(command, output.stem)
                actual, counters = identity(output), read(run['stderr'])
                assert all(actual[k] == old['output'][k] for k in ('bytes', 'sha256'))
                assert run['threads'] == 1 and run['rss_bytes'] <= 2000000000 and run['cpu_s'] <= 3600
                assert counters['rows'] == 1000000 and counters['query_allocations'] == 0
                run.update(arm=arm, iteration=iteration, output=actual, counters=counters,
                    identical_to=old['output'], rebuild_command=command)
                write(ROOT / (output.stem + '-evidence.json'), run)
                output.unlink()
                runs.append(run)
                if iteration:
                    times[arm].append(run['cpu_s'])
                print('EXP594_RUN', case, iteration, arm, run['cpu_s'], flush=True)
        comparisons = {}
        for arm in ARMS[1:]:
            saved = [a-b for a, b in zip(times['A'], times[arm])]
            mean = statistics.mean(saved)
            half = critical * statistics.stdev(saved) / math.sqrt(6)
            comparisons[arm] = dict(saved_cpu_s=mean, simultaneous_ci_saved_s=[mean-half, mean+half],
                gate=bool(mean >= .005 and mean-half > 0))
        results[case] = dict(timing=times, runs=runs, comparisons=comparisons,
            rows=1000000, unique_rows=1000000, port_pairs=59904, accuracy_reused=old['statistics'])
        write(ROOT / (case + '-report.json'), results[case])
    eligible = [a for a in ARMS[1:] if all(r['comparisons'][a]['gate'] for r in results.values())]
    selected = min(eligible, key=lambda a: sum(statistics.mean(r['timing'][a]) for r in results.values())) if eligible else None
    report = dict(cases=results, eligible=eligible, selected=selected, scale_eligible=bool(eligible),
        disk_end_bytes=shutil.disk_usage('.').free, final_goal_achieved=False)
    write(ROOT / 'report.json', report)
    freeze_selected()
    print('EXP594_SELECTED', selected, flush=True)


def freeze_selected():
    fixed = read(ROOT / 'build-freeze.json')
    selected = read(ROOT / 'report.json')['selected']
    if selected:
        check(BASE, fixed['binaries']['A'])
        check(binary(selected), fixed['binaries'][selected])
        view = BUILD / 'view'
        if view.is_symlink():
            assert view.resolve() == binary(selected).resolve()
        else:
            view.symlink_to(selected)
        fixed.update(baseline=fixed['binaries']['A'], binary=fixed['binaries'][selected])
        fixed['qualification_driver'] = identity(__file__)
        write(ROOT / 'freeze.json', fixed)


def ten_million():
    prior.ROOT, prior.BUILD, prior.BASE, prior.PLAN = ROOT, BUILD, BASE, PLAN
    prior.ten_million()


def hundred_million():
    assert read(ROOT / '10m-report.json')['speed_gate']
    frozen = read(ROOT / 'freeze.json')
    candidate = BUILD / 'view'
    check(candidate, frozen['binary'])
    old = Path('../exp580')
    request = old / 'build/exp580/scale-input/requests-100m.csv'
    input_identity = read(old / 'validation/results/exp580/requests-100m-csv-identity.json')
    check(request, input_identity)
    provenance = read(old / 'validation/results/exp580/100m-report.json')
    assert provenance['unique_rows'] == 100000000 and provenance['port_pairs'] == 59904
    checker = old / 'build/exp580/contract-check'
    check(checker, read(old / 'validation/results/exp580/10m-freeze.json')['checker'])
    assert shutil.disk_usage('.').free > 5000000000
    output, sample = BUILD / '100m-view.csv', BUILD / '100m-sample.csv'
    assert not output.exists() and not sample.exists()
    write(ROOT / '100m-freeze.json', dict(binary=frozen['binary'], input=input_identity,
        checker=identity(checker), protocol=identity(PLAN), driver=identity(__file__),
        scoring_helper=identity(prior.__file__), stage_cpu_limit_s=100,
        disk_start_bytes=shutil.disk_usage('.').free))
    before = request.stat()
    run = speed.measured([str(candidate), '-in', str(request), '-out', str(output)], '100m-view')
    after = request.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns)
    assert run['threads'] == 1 and run['rss_bytes'] <= 2000000000 and run['cpu_s'] <= 3600
    counters = read(run['stderr'])
    assert counters['rows'] == 100000000 and counters['query_allocations'] == 0
    check_run = speed.measured([str(checker), 'check', str(request), str(output), '100000000',
        str(old / 'build/exp580/scale-input/positions.txt'), str(sample)], '100m-contract')
    contract = read(ROOT / '100m-contract.stdout')
    assert contract['contract_passed'] and contract['rows'] == 100000000
    assert contract['sample_rows'] == 239616
    evidence = dict(output=identity(output), sample=identity(sample), contract=contract, check_run=check_run)
    run.update(counters=counters, evidence=evidence)
    write(ROOT / '100m-report.json', dict(rows=100000000, unique_rows=100000000, port_pairs=59904,
        input=input_identity, binary=frozen['binary'], run=run, stage_gate=run['cpu_s'] < 100,
        stage_cpu_limit_s=100, disk_end_bytes=shutil.disk_usage('.').free))
    print('EXP594_100M_COMPLETE', run['cpu_s'], flush=True)
    prior.ROOT = ROOT
    prior.scale_accuracy(old, evidence, 100000000)


if __name__ == '__main__':
    assert socket.gethostname() == 'lhj-R4900-G3'
    assert Path.cwd() == Path('/home/lhj/lhjwork/eda2026/research/exp594')
    assert sys.argv[1:] in (['build'], ['qualify'], ['10m'], ['100m'])
    {'build': build, 'qualify': qualify, '10m': ten_million, '100m': hundred_million}[sys.argv[1]]()
