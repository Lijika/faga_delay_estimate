#!/usr/bin/env python3
"""Move every pre-dispatch dynamic initializer into the generic ISA unit."""
from pathlib import Path
import shutil
import socket
import subprocess
import sys

sys.path.insert(0, str(Path('../exp608/validation').resolve()))
import exp608_whole_query as prior
import exp608_scale as scale

ROOT, BUILD = Path('validation/results/exp609'), Path('build/exp609')
PLAN = Path('experiment/实验609-共享通用启动状态的安全指令分派.md')
read, write, identity, check = prior.read, prior.write, prior.identity, prior.check
prior.ROOT, prior.BUILD, prior.PLAN = ROOT, BUILD, PLAN
prior.prior.ROOT, prior.prior.BUILD, prior.prior.speed.ROOT = ROOT, BUILD, ROOT
scale.ROOT, scale.BUILD, scale.PLAN = ROOT, BUILD, PLAN


def build():
    ROOT.mkdir(parents=True, exist_ok=True)
    BUILD.mkdir(parents=True)
    old = Path('../exp608')
    frozen = read(old / 'validation/results/exp608/build-freeze.json')
    for key in ('source', 'entry', 'header'):
        source = old / frozen[key]['path']
        check(source, frozen[key])
        text = source.read_text()
        if key == 'source':
            text = prior.prior.prior.replace(text, 'static delayest::Architecture arch;',
                                            'extern delayest::Architecture arch;')
        elif key == 'entry':
            text = '#include "architecture.h"\ndelayest::Architecture arch;\n' + text
        (BUILD / source.name).write_text(text)
    for name in ('exp596_csv_batch.h', 'exp601_port_parser.h'):
        shutil.copyfile(old / 'build/exp608' / name, BUILD / name)
    dependencies = []
    for item in frozen['dependencies']:
        p = Path(item['path'])
        if p.parts[0] != '..': p = old / p
        check(p, item)
        dependencies.append(identity(p))
    safety = {}
    for arm in ('F', 'S', 'D'):
        for suffix in ('', '-audit'):
            name = arm + suffix
            command = read(old / ('validation/results/exp608/compile-' + name + '.run.json'))['command']
            command = [str(BUILD) + c[len('build/exp608'):] if c.startswith('build/exp608') else c for c in command]
            prior.prior.speed.measured(command, 'compile-' + name)
            assert not (ROOT / ('compile-' + name + '.stderr')).read_bytes()
            obj = BUILD / (name + '.o')
            sections = subprocess.check_output(['readelf', '-SW', str(obj)], text=True)
            symbols = subprocess.check_output(['nm', '-C', '--defined-only', str(obj)], text=True)
            assert '.init_array' not in sections and '_GLOBAL__sub_I' not in symbols
            # Only the selected worker is exported; shared code must stay generic.
            external = [s for s in symbols.splitlines() if ' T ' in s or ' W ' in s]
            assert len(external) == 1 and 'worker608_' + arm in external[0], external
            safety[name] = dict(object=identity(obj), no_dynamic_initializers=True,
                                exported_symbols=external)
    binaries = {'A': identity(prior.prior.prior.BASE)}
    for arm in ('F', 'S', 'D'):
        binaries.update(prior.link(arm))
    shutil.copyfile(PLAN, ROOT / 'protocol-original.md')
    write(ROOT / 'build-freeze.json', dict(binaries=binaries, dependencies=dependencies,
        source=identity(BUILD / 'worker.cpp'), entry=identity(BUILD / 'entry.cpp'),
        header=identity(BUILD / 'exp608_geometry.h'), driver=identity(__file__),
        protocol=identity(ROOT / 'protocol-original.md'), startup_safety=safety,
        base_freeze=identity(old / 'validation/results/exp608/build-freeze.json'),
        disk_start_bytes=shutil.disk_usage('.').free))


def automatic():
    # Every path is retained for the full 10M comparison, including the generic one.
    prior.automatic()


if __name__ == '__main__':
    assert socket.gethostname() == 'lhj-R4900-G3'
    assert Path.cwd() == Path('/home/lhj/lhjwork/eda2026/research/exp609')
    assert sys.argv[1:] in (['build'], ['qualify'], ['automatic'], ['10m'], ['100m'], ['1b'])
    actions = {'build': build, 'qualify': prior.qualify, 'automatic': automatic,
               '10m': scale.ten_million, '100m': lambda: scale.scale('100m'), '1b': lambda: scale.scale('1b')}
    actions[sys.argv[1]]()
