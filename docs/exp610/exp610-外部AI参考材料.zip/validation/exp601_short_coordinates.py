#!/usr/bin/env python3
"""Use an equivalent short-coordinate parser with center prefetch."""
from pathlib import Path
import shutil
import socket
import subprocess
import sys

sys.path.insert(0, str(Path('../exp594/validation').resolve()))
import exp594_packed_output as prior

ROOT, BUILD = Path('validation/results/exp601'), Path('build/exp601')
PLAN = Path('experiment/实验601-短坐标解析与中心项预取.md')
BASE = Path('../exp596/build/exp596/Q')
read, write, identity, check, speed = prior.read, prior.write, prior.identity, prior.check, prior.speed


def configure():
    prior.ROOT, prior.BUILD, prior.PLAN, prior.BASE = ROOT, BUILD, PLAN, BASE
    prior.ARMS = ('A', 'P', 'Q', 'PQ')
    speed.ROOT = ROOT


def write_parser(source, destination):
    text = source.read_text()
    marker = 'static inline bool parsePin580('
    helper = """static inline std::from_chars_result coordinate601(const char* at, const char* end, int& value) {
    if (end - at >= 4) {
        const unsigned a=unsigned(at[0])-'0', b=unsigned(at[1])-'0';
        const unsigned c=unsigned(at[2])-'0', d=unsigned(at[3])-'0';
        if (a < 10) {
            if (b >= 10) { value=int(a); return {at+1, std::errc{}}; }
            if (c >= 10) { value=int(10*a+b); return {at+2, std::errc{}}; }
            if (d >= 10) { value=int(100*a+10*b+c); return {at+3, std::errc{}}; }
        }
    }
    return std::from_chars(at,end,value);
}

"""
    text = prior.replace(text, marker, helper + 'static inline bool parsePin601(')
    text = prior.replace(text, 'std::from_chars(at, end, xx)', 'coordinate601(at, end, xx)')
    text = prior.replace(text, 'std::from_chars(at, end, yy)', 'coordinate601(at, end, yy)')
    wrapper = """static inline bool parsePin580(std::string_view text, int& x, int& y, int& port) {
#ifdef EXP601_VERIFY_PARSER
    int rx=x, ry=y, rp=port;
    const bool expected=arch.parsePin(text,rx,ry,rp);
#endif
    const bool actual=parsePin601(text,x,y,port);
#ifdef EXP601_VERIFY_PARSER
    require(actual==expected && x==rx && y==ry && port==rp, "short coordinate reference mismatch");
#endif
    return actual;
}

"""
    text = prior.replace(text, '#ifdef EXP580_VERIFY_PARSER', wrapper + '#ifdef EXP580_VERIFY_PARSER')
    destination.write_text(text)


def build():
    ROOT.mkdir(parents=True, exist_ok=True)
    assert not (ROOT / "build-freeze.json").exists()
    BUILD.mkdir(parents=True)
    old = Path('../exp596')
    frozen = read(old / 'validation/results/exp596/freeze.json')
    check(BASE, frozen['binary'])
    source = old / frozen['source']['path']
    reader = old / frozen['generated_reader']['path']
    check(source, frozen['source']); check(reader, frozen['generated_reader'])
    original = source.read_text()
    shutil.copyfile(reader, BUILD / 'exp596_csv_batch.h')
    dependencies = []
    for entry in frozen['dependencies']:
        path = Path(entry['path'])
        if path.parts[0] != '..': path = old / path
        check(path, entry)
        dependencies.append(identity(path))
    parser = Path('../exp589/tests/exp580_port_parser.h')
    dependencies.append(identity(parser))
    write_parser(parser, BUILD / 'exp601_port_parser.h')
    dependencies.append(identity(BUILD / 'exp601_port_parser.h'))
    template = read(old / 'validation/results/exp596/compile-Q.run.json')['command']
    sources = {}
    for arm in ('P', 'Q', 'PQ'):
        text = original
        if 'P' in arm:
            text = prior.replace(text, '#include "exp580_port_parser.h"',
                '#include "exp601_port_parser.h"')
        if 'Q' in arm:
            marker = '    const unsigned pair=unsigned(source*288+target), context=(direction*10+bx%10)*12+by%12;\n'
            text = prior.replace(text, marker, marker +
                '    _mm_prefetch(reinterpret_cast<const char*>(center + pair), _MM_HINT_T0);\n')
        candidate = BUILD / (arm + '.cpp')
        candidate.write_text(text)
        sources[arm] = identity(candidate)
        for name in (arm, 'P-audit', 'parser-check') if arm == 'PQ' else (arm,):
            substitutions = {'build/exp596': str(BUILD),
                'build/exp596/candidate.cpp': str(candidate), 'build/exp596/Q': str(BUILD / name)}
            command = [substitutions.get(arg, arg) for arg in template]
            if name.endswith('audit'): command.insert(1, '-DEXP579_AUDIT')
            if name == 'parser-check':
                command[1:1] = ['-DEXP601_VERIFY_PARSER', '-DEXP580_VERIFY_PARSER']
            speed.measured(command, 'compile-' + name)
            assert not (ROOT / ('compile-' + name + '.stderr')).read_bytes()
            assert (BUILD / name).stat().st_size < 100000000
            linked = subprocess.run(['ldd', str(BUILD / name)], capture_output=True, text=True)
            assert 'not a dynamic executable' in linked.stdout + linked.stderr
    shutil.copyfile(PLAN, ROOT / 'protocol-original.md')
    write(ROOT / 'build-freeze.json', dict(binaries={a: identity(prior.binary(a)) for a in prior.ARMS},
        sources=sources, source=identity(source), generated_reader=identity(BUILD / 'exp596_csv_batch.h'),
        dependencies=dependencies, audit_binary=identity(BUILD / 'P-audit'), driver=identity(__file__),
        protocol=identity(ROOT / 'protocol-original.md'), source_freeze=identity(old / 'validation/results/exp596/freeze.json'),
        disk_start_bytes=shutil.disk_usage('.').free))


def qualify():
    expected = read('../exp589/validation/results/exp589/development-report.json')['evidence']['D64']
    request = Path('../exp501/build/exp501/u-role/requests.csv')
    check(request, expected['input'])
    output = BUILD / 'parser-check.csv'
    command = [str(BUILD / 'parser-check'), '-in', str(request), '-out', str(output)]
    run = speed.measured(command, 'parser-check')
    actual = identity(output)
    assert all(actual[k] == expected['output'][k] for k in ('bytes', 'sha256'))
    assert read(run['stderr'])['rows'] == 1000000
    write(ROOT / 'parser-check-evidence.json', dict(run=run, output=actual,
        reference=expected['output'], rows=1000000, port_pairs=59904,
        binary=identity(BUILD / 'parser-check'), checks='every parsed endpoint plus all-port syntax variants'))
    output.unlink()
    prior.qualify()
    selected = read(ROOT / 'report.json')['selected']
    if selected:
        frozen = read(ROOT / 'freeze.json')
        frozen['source'] = frozen['sources'][selected]
        archive = ROOT / 'freeze-before-source-selection.json'
        assert not archive.exists()
        (ROOT / 'freeze.json').rename(archive)
        write(ROOT / 'freeze.json', frozen)


if __name__ == '__main__':
    assert socket.gethostname() == 'lhj-R4900-G3'
    assert Path.cwd() == Path('/home/lhj/lhjwork/eda2026/research/exp601')
    assert sys.argv[1:] in (['build'], ['qualify'], ['10m'], ['100m'])
    configure()
    {'build': build, 'qualify': qualify, '10m': prior.ten_million,
        '100m': prior.hundred_million}[sys.argv[1]]()
