#!/usr/bin/env python3
"""Preserve per-row arithmetic while overlapping frozen background prefetches."""
from pathlib import Path
import shutil
import socket
import subprocess
import sys

sys.path.insert(0, str(Path('../exp594/validation').resolve()))
import exp594_packed_output as prior

ROOT, BUILD = Path('validation/results/exp596'), Path('build/exp596')
PLAN = Path('experiment/实验596-稳定行视图的小批次背景预取.md')
BASE = Path('../exp595/build/exp595/P')
read, write, identity, check, speed = prior.read, prior.write, prior.identity, prior.check, prior.speed
replace = prior.replace


def configure():
    prior.ROOT, prior.BUILD, prior.PLAN, prior.BASE = ROOT, BUILD, PLAN, BASE
    prior.ARMS = ('A', 'P', 'Q')
    speed.ROOT = ROOT


def batch_source(source):
    start = source.index('static inline int predict(')
    end = source.index('\n#ifdef EXP579_AUDIT', start)
    original = source[start:end]
    prefix = original[:original.index('#ifdef EXP581_PREFETCH')]
    prefix = replace(prefix,
        'static inline int predict(const int32_t* q, unsigned fold, Trace* trace = nullptr)',
        'static inline void prepare596(const int32_t* q, unsigned fold, Prepared596& state, Trace* trace = nullptr)')
    prefix = replace(prefix, 'if (sx == tx && sy == ty && sp == tp) return 0;',
        'if (sx == tx && sy == ty && sp == tp) { state.answer=0; return; }')
    assert prefix.count('return -1;') == 2
    prefix = prefix.replace('return -1;', 'return;')
    features = original[original.index('    const int sf='):original.rindex('#ifdef EXP581_PREFETCH')]
    suffix = original[original.rindex('#ifdef EXP581_PREFETCH') + len('#ifdef EXP581_PREFETCH\n'):]
    suffix = replace(suffix,
        '    if (dx==0 && dy==0 && sp==tp && net>=0) nominal=kCycles[source];',
        '    if (state.override_cycle) nominal=state.cycle;')
    suffix = replace(suffix, '#endif\n', '')
    suffix = replace(suffix,
        '        for (unsigned j=0;j<53;++j) trace->feature[j]=float(feature[j]);\n', '')
    state = '''struct Prepared596 {
    unsigned pair=0, context=0, qx=0, qy=0;
    int fee=0, mandatory=0, dy=0, cycle=0, answer=-1;
    float raw=0.f;
    bool override_cycle=false, ready=false;
};

'''
    prepare = prefix + '''    prefetchGeometry581(pair,context,qx,qy);
    const int mandatory=line(sx,sy,ax,ay)+line(ax,ay,tx,ty);
''' + features + '''    state.pair=pair; state.context=context; state.qx=qx; state.qy=qy;
    state.fee=fee; state.mandatory=mandatory; state.dy=dy; state.raw=raw;
    state.override_cycle=dx==0 && dy==0 && sp==tp && net>=0;
    state.cycle=kCycles[source]; state.ready=true;
    if (trace) for (unsigned j=0;j<53;++j) trace->feature[j]=float(feature[j]);
}

'''
    finish = '''static inline int finish596(const Prepared596& state, Trace* trace = nullptr) {
    if (!state.ready) return state.answer;
    const unsigned pair=state.pair, context=state.context, qx=state.qx, qy=state.qy;
    const int fee=state.fee, mandatory=state.mandatory, dy=state.dy;
    const float raw=state.raw;
''' + suffix
    wrapper = '''
static inline int predict(const int32_t* q, unsigned fold, Trace* trace = nullptr) {
    Prepared596 state;
    prepare596(q,fold,state,trace);
    return finish596(state,trace);
}
'''
    source = replace(source, original, state + prepare + finish + wrapper)
    source = replace(source, '#include "exp591_csv_view.h"', '#include "exp596_csv_batch.h"')
    start = source.index('    while (reader.next(text)) {')
    end = source.index('    require(writer.flush()', start)
    loop = source[start:end]
    parse = loop[loop.index('        const size_t comma'):loop.index('        unreachable+=')]
    parse = replace(parse, '        int answer=-1;\n', '')
    parse = replace(parse, '                answer=predict(q,0);', '                prepare596(q,0,states[i]);')
    parse = '\n'.join('    '+line for line in parse.split('\n'))
    batch = '''    std::string_view lines[EXP596_BATCH];
    for (;;) {
        const size_t count=reader.nextBatch(lines,EXP596_BATCH);
        if (!count) break;
        Prepared596 states[EXP596_BATCH];
        for (size_t i=0;i<count;++i) {
            const auto text=lines[i];
''' + parse + '''        }
        for (size_t i=0;i<count;++i) {
            const int answer=finish596(states[i]);
            unreachable+=answer<0;
            require(writer.row(lines[i],answer), "output write");
        }
        rows+=count;
    }
'''
    return replace(source, loop, batch)


def build():
    ROOT.mkdir(parents=True)
    BUILD.mkdir(parents=True)
    old = read('../exp595/validation/results/exp595/freeze.json')
    check(BASE, old['binary'])
    original = Path('../exp595/build/exp595/candidate.cpp')
    check(original, old['source'])
    source = batch_source(original.read_text())
    (BUILD / 'candidate.cpp').write_text(source)
    reader = Path('../exp591/tests/exp591_csv_view.h')
    reader_source = replace(reader.read_text(), ' private:\n',
        Path('tests/exp596_stable_batch.inc').read_text() + '\n private:\n')
    (BUILD / 'exp596_csv_batch.h').write_text(reader_source)
    assets = Path('../exp589/build/exp589/D64-assets')
    dependencies = [Path('tests/exp596_stable_batch.inc'), reader,
        Path('../exp595/tests/exp595_static_geometry.h'), Path('../exp594/tests/exp594_packed_output.h'),
        assets / 'exp582_int8_geometry.h', assets / 'exp579-models.h', assets / 'geometry.o',
        Path('../exp580/build/exp580/architecture-resolver.o'), Path('../exp579/build/exp579/arch-text.o')]
    common = ['g++', '-std=c++17', '-O3', '-fno-exceptions', '-fno-rtti', '-fno-fast-math',
        '-ffp-contract=off', '-march=x86-64', '-mtune=generic', '-Wall', '-Wextra', '-Werror',
        '-DDELAY_ESTIMATE_EMBEDDED_ARCH', '-DDELAY_ESTIMATE_PRECOMPUTED_RESIDUE',
        '-DEXP580_PORT_PARSER', '-DEXP581_PREFETCH', '-DEXP582_BLOCK=64',
        '-DEXP594_PACKED', '-DEXP594_WRITER', '-I', '../exp589/src', '-I', str(assets),
        '-I', str(BUILD), '-I', '../exp595/tests', '-I', '../exp594/tests', '-I', '../exp589/tests']
    for name, capacity in (('P', 4), ('Q', 8), ('P-audit', 4), ('P-reader', 4), ('Q-reader', 8)):
        command = common + [f'-DEXP596_BATCH={capacity}']
        if name.endswith('audit'): command += ['-DEXP579_AUDIT']
        if name.endswith('reader'): command += ['-DEXP591_VERIFY_READER']
        command += [str(BUILD / 'candidate.cpp'), *map(str, dependencies[-2:]), str(assets / 'geometry.o'),
            '-static', '-s', '-Wl,--wrap=malloc,--wrap=calloc,--wrap=realloc', '-o', str(BUILD / name)]
        speed.measured(command, 'compile-' + name)
        assert not (ROOT / ('compile-' + name + '.stderr')).read_bytes()
        assert (BUILD / name).stat().st_size < 100000000
        linked = subprocess.run(['ldd', str(BUILD / name)], capture_output=True, text=True)
        assert 'not a dynamic executable' in linked.stdout + linked.stderr
    shutil.copyfile(PLAN, ROOT / 'protocol-original.md')
    write(ROOT / 'build-freeze.json', dict(binaries={a: identity(prior.binary(a)) for a in prior.ARMS},
        source=identity(BUILD / 'candidate.cpp'), generated_reader=identity(BUILD / 'exp596_csv_batch.h'),
        dependencies=[identity(p) for p in dependencies], audit_binary=identity(BUILD / 'P-audit'),
        reader_binaries={a: identity(BUILD / (a + '-reader')) for a in ('P', 'Q')},
        driver=identity(__file__), protocol=identity(ROOT / 'protocol-original.md'),
        disk_start_bytes=shutil.disk_usage('.').free))


def qualify():
    fixed = read(ROOT / 'build-freeze.json')
    for case, exp in (('development', 'exp501'), ('robustness', 'exp562')):
        request = Path(f'../{exp}/build/{exp}/u-role/requests.csv')
        expected = read(f'../exp589/validation/results/exp589/{case}-report.json')['evidence']['D64']
        check(request, expected['input'])
        for arm in ('P', 'Q'):
            path = BUILD / (arm + '-reader')
            check(path, fixed['reader_binaries'][arm])
            output = BUILD / f'{case}-{arm}-reader.csv'
            command = [str(path), '-in', str(request), '-out', str(output)]
            run = speed.measured(command, output.stem)
            actual = identity(output)
            assert all(actual[k] == expected['output'][k] for k in ('bytes', 'sha256'))
            assert run['threads'] == 1 and run['rss_bytes'] <= 2000000000 and run['cpu_s'] <= 3600
            assert read(run['stderr'])['query_allocations'] == 0
            write(ROOT / (output.stem + '-evidence.json'), dict(run=run, output=actual,
                rows=1000000, port_pairs=59904, identical_to=expected['output'], rebuild_command=command))
            output.unlink()
    prior.qualify()


if __name__ == '__main__':
    assert socket.gethostname() == 'lhj-R4900-G3'
    assert Path.cwd() == Path('/home/lhj/lhjwork/eda2026/research/exp596')
    assert sys.argv[1:] in (['build'], ['qualify'], ['10m'], ['100m'])
    configure()
    {'build': build, 'qualify': qualify, '10m': prior.ten_million,
        '100m': prior.hundred_million}[sys.argv[1]]()
