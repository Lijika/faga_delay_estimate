#!/usr/bin/env python3
"""Specialize frozen D64 INT8 dimensions, retaining the full-port exp594 protocol."""
from pathlib import Path
import shutil
import socket
import subprocess
import sys

sys.path.insert(0, str(Path('../exp594/validation').resolve()))
import exp594_packed_output as prior

ROOT, BUILD = Path('validation/results/exp595'), Path('build/exp595')
PLAN = Path('experiment/实验595-固定维度INT8背景点积.md')
BASE = Path('../exp594/build/exp594/PW')
read, write, identity, check, speed = prior.read, prior.write, prior.identity, prior.check, prior.speed


def configure():
    prior.ROOT, prior.BUILD, prior.PLAN, prior.BASE = ROOT, BUILD, PLAN, BASE
    prior.ARMS = ('A', 'P')
    speed.ROOT = ROOT


def build():
    ROOT.mkdir(parents=True)
    BUILD.mkdir(parents=True)
    old = read('../exp594/validation/results/exp594/freeze.json')
    check(BASE, old['binary'])
    original = Path('../exp594/build/exp594/candidate.cpp')
    check(original, old['source'])
    source = prior.replace(original.read_text(), '#include "exp582_int8_geometry.h"',
        '#define geometry dynamicGeometry595\n#define prefetchGeometry581 dynamicPrefetch595\n'
        '#include "exp582_int8_geometry.h"\n#undef geometry\n#undef prefetchGeometry581\n'
        '#include "exp595_static_geometry.h"')
    (BUILD / 'candidate.cpp').write_text(source)
    assets = Path('../exp589/build/exp589/D64-assets')
    dependencies = [Path('tests/exp595_static_geometry.h'), Path('../exp594/tests/exp594_packed_output.h'),
        Path('../exp591/tests/exp591_csv_view.h'), assets / 'exp582_int8_geometry.h',
        assets / 'exp579-models.h', assets / 'geometry.o',
        Path('../exp580/build/exp580/architecture-resolver.o'), Path('../exp579/build/exp579/arch-text.o')]
    common = ['g++', '-std=c++17', '-O3', '-fno-exceptions', '-fno-rtti', '-fno-fast-math',
        '-ffp-contract=off', '-march=x86-64', '-mtune=generic', '-Wall', '-Wextra', '-Werror',
        '-DDELAY_ESTIMATE_EMBEDDED_ARCH', '-DDELAY_ESTIMATE_PRECOMPUTED_RESIDUE',
        '-DEXP580_PORT_PARSER', '-DEXP581_PREFETCH', '-DEXP582_BLOCK=64',
        '-DEXP594_PACKED', '-DEXP594_WRITER', '-I', '../exp589/src', '-I', str(assets),
        '-I', 'tests', '-I', '../exp594/tests', '-I', '../exp591/tests', '-I', '../exp589/tests']
    for name in ('P', 'P-audit'):
        command = common + (['-DEXP579_AUDIT'] if name.endswith('audit') else []) + [
            str(BUILD / 'candidate.cpp'), *map(str, dependencies[-2:]), str(assets / 'geometry.o'),
            '-static', '-s', '-Wl,--wrap=malloc,--wrap=calloc,--wrap=realloc', '-o', str(BUILD / name)]
        speed.measured(command, 'compile-' + name)
        assert not (ROOT / ('compile-' + name + '.stderr')).read_bytes()
        assert (BUILD / name).stat().st_size < 100000000
        linked = subprocess.run(['ldd', str(BUILD / name)], capture_output=True, text=True)
        assert 'not a dynamic executable' in linked.stdout + linked.stderr
    shutil.copyfile(PLAN, ROOT / 'protocol-original.md')
    write(ROOT / 'build-freeze.json', dict(binaries={'A': identity(BASE), 'P': identity(BUILD / 'P')},
        source=identity(BUILD / 'candidate.cpp'), dependencies=[identity(p) for p in dependencies],
        audit_binary=identity(BUILD / 'P-audit'), driver=identity(__file__),
        protocol=identity(ROOT / 'protocol-original.md'), disk_start_bytes=shutil.disk_usage('.').free))


if __name__ == '__main__':
    assert socket.gethostname() == 'lhj-R4900-G3'
    assert Path.cwd() == Path('/home/lhj/lhjwork/eda2026/research/exp595')
    assert sys.argv[1:] in (['build'], ['qualify'], ['10m'], ['100m'])
    configure()
    {'build': build, 'qualify': prior.qualify, '10m': prior.ten_million,
        '100m': prior.hundred_million}[sys.argv[1]]()
